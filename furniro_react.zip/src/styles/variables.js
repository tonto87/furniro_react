
export const variables = {
    black: "#000",
    grey1: "#3a3a3a",
    grey2: "#616161",
    grey3: "#898989",
    grey4: "#b0b0b0",
    grey5: "#d8d8d8",
    greenAccents: "#2ec1ac",
    lightBG: "#f4f5f7",
    redAccents: "#e97171",
    white: "#fff",
    fontColor: "#333",
    fontColor1: "#666",
    fontLight: "#9f9f9f",
    primary: "#b88e2f",
    cream: "#fcf8f3",
    cream2: "#fff3e3",
    lightwhite: "#fefefe",
    lightgrey: "#888",
    smoke: "#d9d9d9",
    fonts: {
      montserrat: "'Montserrat', sans-serif",
      poppins: "'Poppins', sans-serif"
  }
  };
  