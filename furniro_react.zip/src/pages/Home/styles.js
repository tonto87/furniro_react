import styled from "styled-components";



export const HomeStyle = styled.div`
 
`;
