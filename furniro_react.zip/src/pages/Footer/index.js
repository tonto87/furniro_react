export { default } from "./Footer";

export * from "./styles";
