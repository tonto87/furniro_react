import React from "react";
import { useCart } from "../../context/CartContext";

const Shop = () => {
  const { dispatch } = useCart();

  return (
    <div>
      {/* <Title $hide={hidden}>About Page</Title> */}
    </div>
  );
};

export default Shop;
