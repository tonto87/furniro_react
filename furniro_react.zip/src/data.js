import img1 from "../src/assets/images/image 1.png";
import img2 from "../src/assets/images/image 2.png";
import img3 from "../src/assets/images/image 3.png";
import img4 from "../src/assets/images/image 4.png";
import img5 from "../src/assets/images/image 9.png";
import img6 from "../src/assets/images/image 6.png";
import img7 from "../src/assets/images/image 7.png";
import img8 from "../src/assets/images/image 8.png";

export const products = [
  {
    id: 1,
    img: img1,
    name: "Wireless Headphones",
    paragraph: "Dining",
    price: 89.99,
  },
  {
    id: 2,
    img: img2,
    name: "Smart Watch",
    paragraph: "Bed",
    price: 149.99,
  },
  {
    id: 3,
    img: img3,
    name: "Gaming Mouse",
    paragraph: "Kitchen",
    price: 49.99,
  },
  {
    id: 4,
    img: img4,
    name: "4K Monitor",
    paragraph: "mitchen",
    price: 299.99,
  },
  {
    id: 5,
    img: img5,
    name: "Bluetooth Speaker",
    paragraph: "bathroom",
    price: 59.99,
  },
  {
    id: 6,
    img: img6,
    name: "Mechanical Keyboard",
    paragraph: "toilet",
    price: 79.99,
  },
  {
    id: 7,
    img: img7,
    name: "USB-C Hub",
    paragraph: "qostinniy",
    price: 34.99,
  },
  {
    id: 8,
    img: img8,
    name: "Laptop Stand",
    paragraph: "detskiy",
    price: 39.99,
  },
];
